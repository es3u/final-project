package com.example.finalproject.Api;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}
