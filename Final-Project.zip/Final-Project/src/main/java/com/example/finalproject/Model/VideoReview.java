package com.example.finalproject.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class VideoReview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    private String title;

    @Column
    private String description;

    @Lob
    @Column(nullable = false)
    private byte[] videoData;

    @Column(nullable = false)
    private LocalDate uploadDate;

    @Column
    private String fileName;

    @Column
    private String filePath;

    @Column
    private String contentType;

    @Column
    private Boolean isLiked = false;

    @ManyToOne
    @JsonIgnore
    private Game game;

    @ManyToOne
    @JsonIgnore
    private Reviewer reviewer;
}
