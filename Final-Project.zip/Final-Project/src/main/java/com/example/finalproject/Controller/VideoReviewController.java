package com.example.finalproject.Controller;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.DTO.VideoReviewIDTO;
import com.example.finalproject.Model.MyUser;
import com.example.finalproject.Model.VideoReview;
import com.example.finalproject.Service.VideoReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/videos")
@RequiredArgsConstructor
public class VideoReviewController {


        private final VideoReviewService videoService;

        // رفع فيديو
        @PostMapping("/upload/{gameId}")
        public ResponseEntity<String> uploadVideo(
                @AuthenticationPrincipal MyUser user,
                @PathVariable Integer gameId,
                @RequestParam("file") MultipartFile file) {
            try {
                videoService.uploadVideo(user.getId(), gameId,file);
                return ResponseEntity.ok("Video uploaded successfully");
            } catch (ApiException e) {
                return ResponseEntity.badRequest().body(e.getMessage());
            } catch (IOException e) {
                return ResponseEntity.internalServerError().body("Failed to upload video");
            }
        }


        @GetMapping("/view/{videoId}")
        public ResponseEntity<byte[]> viewVideo(@PathVariable Integer videoId) {
            try {
                byte[] videoData = videoService.getVideo(videoId);
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_TYPE, "video/mp4")
                        .body(videoData);
            } catch (ApiException e) {
                return ResponseEntity.badRequest().body(e.getMessage().getBytes());
            }
        }


        @PutMapping("/like/{videoId}")
        public ResponseEntity<String> likeVideo(
                @AuthenticationPrincipal Integer developerId,
               @PathVariable Integer videoId) {
            try {
                videoService.isLiked(developerId, videoId);
                return ResponseEntity.ok("Video liked successfully");
            } catch (ApiException e) {
                return ResponseEntity.badRequest().body(e.getMessage());
            }
        }

//        @GetMapping("/getDescriptionByVeideoId/{videoId}")
//        public ResponseEntity getDescriptionByVeideoId(@AuthenticationPrincipal MyUser user, @PathVariable Integer videoId) {
//           return  ResponseEntity.ok().body(videoService.getDescriptionByVeideoId(user.getId() , videoId));
//        }
    }

