package com.example.finalproject.Service;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.DTO.TransactionODTO;
import com.example.finalproject.Model.*;
import com.example.finalproject.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TransactionService {
    private final TransactionRepository transactionRepository;
    private final GameRepository gameRepository;
    private final PlayerRepository playerRepository;
    private final AuthRepository authRepository;
    private final EmailNotificationService emailNotificationService;
    private final AnalyticsRepository analyticsRepository;
    private final ReviewerRepository reviewerRepository;

    public Double calculateTotalEarnings(Integer gameId) {
        return transactionRepository.findTransactionsByGame_Id(gameId)
                .stream()
                .mapToDouble(Transaction::getAmount)
                .sum();
    }

    public TransactionODTO buyGame(Integer userId, Integer gameId) {
        Player player = playerRepository.findPlayerById(userId);
        if(player ==null) throw new ApiException("Player not found");

        if(player.getMyUser().isBanned())throw new ApiException("User is banned");

        Game game = gameRepository.findGameById(gameId);
        if(game ==null) throw new ApiException("Game not found");

        if (!game.isValidated())throw new ApiException("Game is not validated");
        if (game.getReleaseDate().isAfter(LocalDate.now()))throw new ApiException("Game is not released yet");

        player.getGames().add(game);
        player.setGamesPurchased(player.getGames().size()+1);

        if (game.getAnalytics() == null){
            Analytics analytics = new Analytics(null,0,0,0.0,0.0,null,game,null);
            analytics = analyticsRepository.save(analytics);
            game.setAnalytics(analytics);
        }

        game.getAnalytics().setTotalDownloads(game.getAnalytics().getTotalDownloads() + 1);
        analyticsRepository.save(game.getAnalytics());


        player.getGames().add(game);
        game.getPlayers().add(player);
        gameRepository.save(game);
        playerRepository.save(player);

        Transaction transaction = new Transaction();
        transaction.setPlayer(player);
        transaction.setGame(game);
        transaction.setAmount(game.getPrice());
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setActivationCode(generateCode());
        transaction.setOrderNumber(UUID.randomUUID().toString());
        transaction.setStatus("COMPLETED");
        transaction.setOrderNumber(UUID.randomUUID().toString());

        transactionRepository.save(transaction);
        emailNotificationService.sendBuyEmail(player.getMyUser().getEmail(), game.getName(), transaction);

        return convertTransactionToDTO(transaction);
    }

    public void preOrderGame(Integer playerId, Integer gameId) {
        Player player = playerRepository.findPlayerById(playerId);
        if(player ==null) throw new ApiException("Player not found");

        if(player.getMyUser().isBanned())throw new ApiException("User is banned");

        Game game = gameRepository.findGameById(gameId);
        if(game ==null) throw new ApiException("Game not found");

        if (game.getReleaseDate() == null || game.getReleaseDate().isBefore(LocalDate.now())) {
            throw new ApiException("This game is not available for pre-order.");
        }

        if (game.getPreOrders().contains(player)) throw new ApiException("Player has already pre-ordered this game.");

        if (game.getAnalytics() == null){
            Analytics analytics = new Analytics(null,0,0,0.0,0.0,null,game,null);
            analytics = analyticsRepository.save(analytics);
            game.setAnalytics(analytics);
        }

        Transaction transaction = new Transaction();
        transaction.setPlayer(player);
        transaction.setGame(game);
        transaction.setAmount(game.getPrice());
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setActivationCode(generateCode());
        transaction.setStatus("COMPLETED");
        transaction.setOrderNumber(UUID.randomUUID().toString());

        transactionRepository.save(transaction);
        game.getPreOrders().add(player);
        gameRepository.save(game);
    }

    public TransactionODTO reviewTrial(Integer userId, Integer gameId) {
        Reviewer reviewer = reviewerRepository.findReviewerByReviewerId(userId);
        if(reviewer ==null) throw new ApiException("Reviewer not found");

        if(reviewer.getMyUser().isBanned())throw new ApiException("User is banned");

        Game game = gameRepository.findGameById(gameId);
        if(game ==null) throw new ApiException("Game not found");

        if (!game.isValidated())throw new ApiException("Game is not validated");


        if (game.getAnalytics() == null){
            Analytics analytics = new Analytics(null,0,0,0.0,0.0,null,game,null);
            analytics = analyticsRepository.save(analytics);
            game.setAnalytics(analytics);
        }


        reviewer.getGames().add(game);


        gameRepository.save(game);

        reviewerRepository.save(reviewer);

        Transaction transaction = new Transaction();
        transaction.setPlayer(null);
        transaction.setGame(game);
        transaction.setAmount(0.0);
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setActivationCode(generateCode());
        transaction.setStatus("COMPLETED");
        transaction.setOrderNumber(UUID.randomUUID().toString());

        transactionRepository.save(transaction);
        emailNotificationService.sendTrialEmail(reviewer.getMyUser().getEmail(), game.getName(), transaction);

        return convertTransactionToDTO(transaction);
    }


    @Scheduled(cron = "0 0 6 * * ?")
    public void sendActivationCodes() {
        Iterable<Game> gamesReleasingToday = gameRepository.findGamesByReleaseDate(LocalDate.now());

        for (Game game : gamesReleasingToday) {
            for (Player player : game.getPreOrders()) {

                String activationCode = generateCode();

                emailNotificationService.sendActivationEmail(player.getMyUser().getEmail(), game.getName(), activationCode);
            }
        }
    }

    public String generateCode() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    //Raghad 9
    public List<TransactionODTO> getPlayerTransactionHistory(Integer playerId) {
        // Ensure the player exists
        Player player = playerRepository.findPlayerById(playerId);
               if(player==null){ throw new ApiException("Player not found");}

        // Retrieve all transactions for the player
        return convertTransactionToOutDTO(transactionRepository.findAllByPlayerId(player.getId()));
    }



    public List<TransactionODTO> convertTransactionToOutDTO(List<Transaction> transactions){
        List<TransactionODTO> transactionODTOS = new ArrayList<>();
        for(Transaction transaction : transactions){
           transactionODTOS.add(new TransactionODTO(transaction.getOrderNumber(), transaction.getTransactionDate(),
                   transaction.getAmount(),transaction.getStatus(),transaction.getActivationCode()));
        }
        return transactionODTOS;
    }

    public TransactionODTO convertTransactionToDTO(Transaction transaction) {
        return new TransactionODTO(transaction.getOrderNumber(),LocalDateTime.now()
                ,transaction.getAmount(),transaction.getStatus(),transaction.getActivationCode());
    }




}
