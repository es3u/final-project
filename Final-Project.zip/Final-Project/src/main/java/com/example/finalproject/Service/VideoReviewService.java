package com.example.finalproject.Service;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.DTO.VideoReviewIDTO;
import com.example.finalproject.Model.Game;
import com.example.finalproject.Model.Player;
import com.example.finalproject.Model.Reviewer;
import com.example.finalproject.Model.VideoReview;
import com.example.finalproject.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VideoReviewService {

    private final VideoReviewRepository videoReviewRepository;
    private final GameRepository gameRepository;
    private final ReviewerRepository reviewerRepository;

    public void uploadVideoReview(Integer reviewerId, Integer gameId, VideoReviewIDTO videoReviewIDTO) {
        Reviewer reviewer = reviewerRepository.findReviewerByReviewerId(reviewerId);
        if (reviewer == null) throw new ApiException("Reviewer not found");

        Game game = gameRepository.findGameById(gameId);
        if (game == null) throw new ApiException("game not found");


        VideoReview videoReview = new VideoReview();
        videoReview.setTitle(videoReviewIDTO.getTitle());
        videoReview.setDescription(videoReviewIDTO.getDescription());
        videoReview.setVideoPath(videoReviewIDTO.getVideoPath());
        videoReview.setUploadDate(LocalDate.now());
        videoReview.setGame(game);
        videoReview.setReviewer(reviewer);

        videoReviewRepository.save(videoReview);
    }
}
