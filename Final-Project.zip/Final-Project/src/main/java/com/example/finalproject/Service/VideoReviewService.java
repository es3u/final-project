package com.example.finalproject.Service;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.DTO.VideoReviewIDTO;
import com.example.finalproject.Model.*;
import com.example.finalproject.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VideoReviewService {

    private final VideoReviewRepository videoReviewRepository;
    private final GameRepository gameRepository;
    private final ReviewerRepository reviewerRepository;
    private final DeveloperRepository developerRepository;
    private final AuthRepository authRepository;

//    public void uploadVideoReview(Integer reviewerId, Integer gameId, VideoReviewIDTO videoReviewIDTO) {
//        Reviewer reviewer = reviewerRepository.findReviewerByReviewerId(reviewerId);
//        if (reviewer == null) throw new ApiException("Reviewer not found");
//
//        Game game = gameRepository.findGameById(gameId);
//        if (game == null) throw new ApiException("game not found");
//
//
//        VideoReview videoReview = new VideoReview();
//        videoReview.setTitle(videoReviewIDTO.getTitle());
//        videoReview.setDescription(videoReviewIDTO.getDescription());
//        videoReview.set(videoReviewIDTO.getVideoPath());
//        videoReview.setUploadDate(LocalDate.now());
//        videoReview.setGame(game);
//        videoReview.setReviewer(reviewer);
//
//        videoReviewRepository.save(videoReview);
//    }
public void uploadVideo(Integer userId, Integer gameId ,MultipartFile file) throws IOException {
    MyUser myUser = authRepository.findMyUserById(userId);
    if (myUser == null) throw new ApiException("User not found");

    if (myUser.isBanned()) throw new ApiException("User is banned");
    Game game = gameRepository.findGameById(gameId);
    Developer developer = developerRepository.findDeveloperById(myUser.getId());
    if (!game.getDeveloper().equals(developer)) {
        throw new ApiException("You are not in this game");
    }

    if (!developer.isValidated()) throw new ApiException("developer not validated");

    if (!file.getContentType().startsWith("video/")) {
        throw new ApiException("Invalid video file");
    }


    VideoReview videoReview = new VideoReview();
    videoReview.setReviewer(myUser.getReviewer());
    videoReview.setVideoData(file.getBytes());
    videoReview.setFileName(file.getOriginalFilename());
    videoReview.setContentType(file.getContentType());



    videoReview.setGame(gameRepository.findGameById(gameId));
    videoReviewRepository.save(videoReview);

}
//    public VideoReviewIDTO getDescriptionByVeideoId(Integer userId ,Integer videoReviewId) {
//        MyUser myUser = authRepository.findMyUserById(userId);
//        if (myUser == null) throw new ApiException("User not found");
//
//        VideoReview videoReview = videoReviewRepository.findVideoReviewById(videoReviewId);
//        if (videoReview == null) throw new ApiException("Video review not found");
//        VideoReviewIDTO videoReviewIDTO = new VideoReviewIDTO(videoReview.getTitle() , videoReview.getDescription()) ;
//
//
//
//        return videoReviewIDTO;
//    }

    public byte[] getVideo(Integer videoId) {
        VideoReview video = videoReviewRepository.findVideoReviewById(videoId);

        if (video == null) throw new ApiException("Video not found");

        if (video.getIsLiked() == false) throw new ApiException("Liked video does not exist");

        return video.getVideoData();
    }



    public void isLiked(Integer developerId , Integer videoId){
        VideoReview videoReview = videoReviewRepository.findVideoReviewById(videoId);
        if (videoReview == null){
            throw new ApiException("Video Review Not Found");
        }
        Developer developer = developerRepository.findDeveloperById(developerId);
        if (developer == null){
            throw new ApiException("Developer Not Found");
        }

        if (videoReview.getGame().getDeveloper() != developer){
            throw new ApiException("You are not in this game");
        }

        if (videoReview.getIsLiked() == true){
            throw new ApiException("You are already liked");
        }
        videoReview.setIsLiked(true);
        videoReviewRepository.save(videoReview);
    }
}
