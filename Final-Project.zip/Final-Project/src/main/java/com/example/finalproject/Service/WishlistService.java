package com.example.finalproject.Service;

import com.example.finalproject.Api.ApiException;
import com.example.finalproject.DTO.WishlistODTO;
import com.example.finalproject.Model.Game;
import com.example.finalproject.Model.MyUser;
import com.example.finalproject.Model.Player;
import com.example.finalproject.Model.Wishlist;
import com.example.finalproject.Repository.AuthRepository;
import com.example.finalproject.Repository.GameRepository;
import com.example.finalproject.Repository.PlayerRepository;
import com.example.finalproject.Repository.WishlistRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class WishlistService {
    private final WishlistRepository wishlistRepository;
    private final AuthRepository authRepository;
    private final GameRepository gameRepository;
    private final PlayerRepository playerRepository;
    private final GameService gameService;

    public WishlistODTO getWishlistById(Integer userId){
        MyUser user = authRepository.findMyUserById(userId);
        if(user == null)throw new ApiException("User not found");

        Wishlist wishlist = wishlistRepository.findWishlistByPlayerId(userId);
        WishlistODTO wishlistODTO = new WishlistODTO();
        wishlistODTO.setGames(gameService.convertGameToGameODTO(wishlist.getGames()));

        return wishlistODTO;
    }


    public void addGameToWishlist(Integer userId, Integer gameId) {
        MyUser myUser = authRepository.findMyUserById(userId);
        if (myUser == null) throw new ApiException("User not found");

        if(myUser.isBanned())throw new ApiException("User is banned");


        Wishlist wishlist = wishlistRepository.findWishlistByPlayerId(userId);
        if (wishlist == null) {
            wishlist = createNewWishlist(userId);
        }

        Game game = gameRepository.findGameById(gameId);
        if (game == null) throw new ApiException("Game not found");


       if(!wishlist.getGames().isEmpty())if (wishlist.getGames().contains(game)) throw new ApiException("Game already in wishlist");

        game.getWishlist().add(wishlist);
        gameRepository.save(game);
        wishlistRepository.save(wishlist);
    }

    public void removeGameFromWishlist(Integer userId, Integer gameId) {
        MyUser myUser = authRepository.findMyUserById(userId);
        if (myUser == null) throw new ApiException("User not found");
        if(myUser.isBanned())throw new ApiException("User is banned");

        Wishlist wishlist = wishlistRepository.findWishlistByPlayerId(userId);
        if (wishlist == null) throw new ApiException("Wishlist not found");

        Game game = gameRepository.findGameById(gameId);
        if (game == null) throw new ApiException("Game not found");

        wishlist.getGames().remove(game);
        game.getWishlist().remove(wishlist);

        gameRepository.save(game);
        wishlistRepository.save(wishlist);
    }


    private Wishlist createNewWishlist(Integer playerId) {
        Player player = playerRepository.findPlayerById(playerId);
        if (player == null) throw new ApiException("Player not found");

        Wishlist wishlist = new Wishlist();
        wishlist.setPlayer(player);
        wishlistRepository.save(wishlist);

        return wishlist;
    }



}
